<html>
<head>
function myfunction(){
    var a=23;
	alert("value :"+a);
	var b=comfirm("Do you continue?");
	if(b==true){
	   alert("success selected");
	}else
	{
	   alert("failure selected");
	}
	var x=prompt("enter number");
	var y=prompt("enter number");
	var s=parseInt(a)+parseInt(b)
	alert("addition : "+ s);


}
</head>
<body>

</body>

</html>