<?php
header('Content-Type: text/xml');
$str="<items><item>pepsi</item><item>coke</item><item>thumps up</item><item>limca</item><item>sprite</item></items>";
echo $str;
?>