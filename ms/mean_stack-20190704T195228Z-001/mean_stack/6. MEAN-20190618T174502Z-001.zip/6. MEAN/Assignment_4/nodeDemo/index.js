var http = require("http");
var fs = require("fs");
var query = require("querystring");

function getRoute() { }

function login(req, res) {
    var route = req.url;

    res.writeHead(200, { 'Content-Type': 'text/html' });
    switch (route) {
        case '/':
            fs.readFile('form.html', function (err, data) {
                if (err) {
                    res.write('Some Error');
                    console.log(err);
                } else {
                    res.write(data);
                    res.end();
                }
            });

            break;

        default:
            res.write('In default');
            res.end();
            break;
    }

}
http.createServer(login).listen(2000);