var http = require("http");
var fs = require("fs");
var query = require("querystring");


fs.readFile('users.txt', function (err, data) {
    if (err) {
        console.log(err);
    } else {
        if ()
            console.log(data.toString());
    }
});