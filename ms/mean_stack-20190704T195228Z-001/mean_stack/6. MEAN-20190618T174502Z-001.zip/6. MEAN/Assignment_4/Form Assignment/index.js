var http = require('http');
var fs = require('fs');
var url = require('url');
var query = require('querystring');

function displayOption(res) {
    fs.readFile("home.html", function (err, data) {
        if (err) {
            res.write("some error");
            console.log(err);
        } else {
            res.write(data);
            res.end();
        }
    });
}
function checkUser(res, username, password) {
    fs.readFile("users.txt", function (err, data) {
        if (err) {
            console.log('Error ' + err);
        } else {
            var line = data.toString().split("\n");
            for (i in line) {
                var arr = line[i].split(",");
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] === username) {
                        if (arr[i + 1] === password) {
                            flag = true;
                            msg = "User Authenticated";
                            break;
                        }
                        else {
                            msg = "Password is incorrect";
                        }
                    }
                    else {
                        msg = "Username not found";
                    }
                }
            }
            res.write(msg);
            if(flag){
                displayOption(res);
            }else{
                res.end();
            }
        }
    });
}


function login(req, res) {
    flag = false;
    msg = '';
    res.write("<h1>Hello world</h1>");
    var p = url.parse(req.url);
    var q = query.parse(p.query);
    switch (p.pathname) {
        case "/":
            fs.readFile("form.html", function (err, data) {
                if (err) {
                    res.write("some error");
                    console.log(err);
                } else {
                    res.write(data);
                    res.end();
                }
            });
            break;

        case "/login":
            checkUser(res, q.username, q.password);
            break;
        default:
            res.write("in default case");
            res.end();
    }
}
http.createServer(login).listen(3000);
console.log("Server started");
